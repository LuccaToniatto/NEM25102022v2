﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace NEMApp
{
    public class RelatorioK
    {
        public int Id { get; set; }
        public int Kelvin { get; set; }
        public int Pressao { get; set; }
        public DateTime Data { get; set; }
        public string alerta { get; set; }

        public List<RelatorioK> listaRelatorioK()
        {
            SqlConnection con = ClassConexao.ObterConexao();
            List<RelatorioK> li = new List<RelatorioK>();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Relatorio";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RelatorioK re = new RelatorioK();
                re.Id = (int)dr["Id"];
                re.Kelvin = (int)dr["temperaturak"];
                re.Pressao = (int)dr["pressao"];
                re.Data = Convert.ToDateTime(dr["data"]);
                re.alerta = dr["alerta"].ToString();
                li.Add(re);
            }
            return li;
        }

        public List<RelatorioK> listaRelatorioKAlerta()
        {
            SqlConnection con = ClassConexao.ObterConexao();
            List<RelatorioK> li = new List<RelatorioK>();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Relatorio where alerta ='!'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RelatorioK re = new RelatorioK();
                re.Id = (int)dr["Id"];
                re.Kelvin = (int)dr["temperaturak"];
                re.Pressao = (int)dr["pressao"];
                re.Data = Convert.ToDateTime(dr["data"]);
                re.alerta = dr["alerta"].ToString();
                li.Add(re);
            }
            return li;
        }
    }
}
