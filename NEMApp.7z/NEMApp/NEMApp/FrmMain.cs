using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Text.Json;
namespace NEMApp
{
    public partial class FrmMain : MetroFramework.Forms.MetroForm
    {


        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            MenuVertical.Width = 55;
            DGVRisco.Visible = true;
            DGVPesquisaNormal.Visible = false;
            DGVRiscoPesquisa.Visible = false;
            DGVNormal.Visible = false;
            this.StyleManager = msmManager;
            msmManager.Theme = MetroFramework.MetroThemeStyle.Dark;
            msmManager.Style = MetroFramework.MetroColorStyle.Purple;
            cbModoPesquisa.Visible = false;
            mtbProcurar.Visible = false;
            mtbLocalizarEntre.Visible = false;
            mcbDatas.Visible = false;
            mdtpDataSetting.Visible = false;
            RelatorioFull rela = new RelatorioFull();
            List<RelatorioFull> li = rela.listaRelatorioFull();
            DGVNormal.DataSource = li;
            RelatorioFull rela2 = new RelatorioFull();
            List<RelatorioFull> li2 = rela2.listaRelatorioFullAlerta();
            DGVRisco.DataSource = li2;
            TimerRelatorio.Interval = 60000;
            TimerRelatorio.Enabled = true;
            this.TimerRelatorio.Tick += new System.EventHandler(this.TimerRelatorio_Tick);

        }

        private void pbxMenu_Click(object sender, EventArgs e)
        {
            if (MenuVertical.Width == 231)
            {
                MenuVertical.Width = 55;
                mtpHoje.Location = new Point(60, 35);
                lbldataatual.Location = new Point(60, 15);
                lblTotalAlarmes.Location = new Point(60,75);
                lblTotalAlarmesResultado.Location = new Point(239,75);
                lbldiv1.Location = new Point(60,102);
                lbldiv2.Location = new Point(60, 155);
                cbModoPesquisa.Visible = false;
                lblMediaAlarmesPorDia.Location = new Point(60,176);
                lblMediaAlarmesPorDiaResultado.Location = new Point(175,176);
                lblMediaPorHora.Location = new Point(60,126);
                lblMediaPorHoraResultado.Location = new Point(175,126);
                pbxLogo.Visible = true;
                mtbProcurar.Visible = false;
                mtbLocalizarEntre.Visible = false;
                mcbDatas.Visible = false;
                mdtpDataSetting.Visible = false;

            }
            else
            {
                MenuVertical.Width = 231;
                pbxLogo.Visible = false;
                mtpHoje.Location = new Point(236, 35);
                lbldataatual.Location = new Point(236, 15);
                lblTotalAlarmes.Location = new Point(236, 75);
                lblTotalAlarmesResultado.Location = new Point(415, 75);
                lbldiv1.Location = new Point(236, 102);
                lblMediaPorHora.Location = new Point(236, 126);
                lblMediaPorHoraResultado.Location = new Point(351, 126);
                lbldiv2.Location = new Point(236, 155);
                lblMediaAlarmesPorDia.Location = new Point(236, 176);
                lblMediaAlarmesPorDiaResultado.Location = new Point(351, 176);
                mtbProcurar.Visible = true;
                mtbLocalizarEntre.Visible = true;
                mcbDatas.Visible = true;
                mdtpDataSetting.Visible = true;
                cbModoPesquisa.Visible = true;
            }
        }

        private void cbxTemperatura_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void mtbEscolher_Click(object sender, EventArgs e)
        {

        }

        private void mtbRecarregar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mtbEscolher_Click_1(object sender, EventArgs e)
        {
            if(mtcbTemperaturas.Text == "C�")
            {
                RelatorioC relatorioC = new RelatorioC();
                List<RelatorioC> rel = relatorioC.listaRelatorioC();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text == "F�")
            {
                RelatorioF relatorioC = new RelatorioF();
                List<RelatorioF> rel = relatorioC.listaRelatorioF();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text == "K�")
            {
                RelatorioK relatorioC = new RelatorioK();
                List<RelatorioK> rel = relatorioC.listaRelatorioK();
                DGVNormal.DataSource = rel;
            }
            if(mtcbTemperaturas.Text== "Todas")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
            else if(mtcbTemperaturas.Text == "")
            {
                MessageBox.Show("Por favor selecione um tipo de relatorio para ser listado na combo box abaixo!");
            }

        }

        private void mtbRecarregar_Click_1(object sender, EventArgs e)
        {
            if(mtcbTemperaturas.Text == "C�")
            {
                RelatorioC relatorioC = new RelatorioC();
                List<RelatorioC> rel = relatorioC.listaRelatorioC();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "F�")
            {
                RelatorioF relatorioC = new RelatorioF();
                List<RelatorioF> rel = relatorioC.listaRelatorioF();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "K�")
            {
                RelatorioK relatorioC = new RelatorioK();
                List<RelatorioK> rel = relatorioC.listaRelatorioK();
                DGVNormal.DataSource = rel;
            }
            if (mtcbTemperaturas.Text == "Todas")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
            else if (mtcbTemperaturas.Text == "")
            {
                RelatorioFull rela = new RelatorioFull();
                List<RelatorioFull> li = rela.listaRelatorioFull();
                DGVNormal.DataSource = li;
            }
        }

        private void cbRisco_CheckedChanged(object sender, EventArgs e)
        {
            if (cbRisco.Checked == true)
            {
                if(cbModoPesquisa.Checked)
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = false;
                    DGVRiscoPesquisa.Visible = true;
                }
                else
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = true;
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFullAlerta();
                    DGVRisco.DataSource = li;
                }
            }
            else if (cbRisco.Checked == false)
            {
                if (cbModoPesquisa.Checked)
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = true;
                    DGVRiscoPesquisa.Visible = false;
                }
                else
                {
                    DGVNormal.Visible = true;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = false;
                    DGVRiscoPesquisa.Visible = false;
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFullAlerta();
                    DGVRisco.DataSource = li;
                }
            }
        }


        private void TimerRelatorio_Tick(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(@"C:\Users\Aluno\Documents\projetos\NEM25102022-main\NEM\NEMApp\Relatorio.json"))
            {
                string json = reader.ReadToEnd();
                json = Regex.Replace(json, "[{},]", string.Empty);
                json = json.Replace("\"", "");
                String[] substrings = json.Split('\n');
                int temperaturaC = Convert.ToInt32(substrings[0]);
                int pressao = Convert.ToInt32(substrings[1]);
                int kelvin = temperaturaC + 273;
                int farenheit = (temperaturaC*9/5)+32;
                RelatorioFull relatorioFull = new RelatorioFull();
                string alerta;
                if (temperaturaC >= 35)
                {
                     alerta = "!";
                }
                else
                {
                     alerta = "";
                }
                relatorioFull.cadastrarrelatorio(temperaturaC, kelvin, farenheit, pressao, mtpHoje.Value, alerta);

                if (mtcbTemperaturas.Text == "C�")
                {
                    RelatorioC relatorioC = new RelatorioC();
                    List<RelatorioC> rel = relatorioC.listaRelatorioC();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "F�")
                {
                    RelatorioF relatorioC = new RelatorioF();
                    List<RelatorioF> rel = relatorioC.listaRelatorioF();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "K�")
                {
                    RelatorioK relatorioC = new RelatorioK();
                    List<RelatorioK> rel = relatorioC.listaRelatorioK();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "Todas")
                {
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFull();
                    DGVNormal.DataSource = li;
                }
                else if (mtcbTemperaturas.Text == "")
                {
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFull();
                    DGVNormal.DataSource = li;
                }
            }
            
        }

        private void btnForcar_Click(object sender, EventArgs e)
        {
            using (StreamReader reader = new StreamReader(@"C:\Users\Aluno\Documents\projetos\NEM25102022-main\NEM\NEMApp\Relatorio.json"))
            {
                string json = reader.ReadToEnd();
                json = Regex.Replace(json, "[{},]", string.Empty);
                json = json.Replace("\"", "");
                String[] substrings = json.Split('\n');
                int temperaturaC = Convert.ToInt32(substrings[0]);
                int pressao = Convert.ToInt32(substrings[1]);
                int kelvin = temperaturaC + 273;
                int farenheit = (temperaturaC * 9 / 5) + 32;
                RelatorioFull relatorioFull = new RelatorioFull();
                string alerta;
                if (temperaturaC >= 35)
                {
                    alerta = "!";
                }
                else
                {
                    alerta = "";
                }
                relatorioFull.cadastrarrelatorio(temperaturaC, kelvin, farenheit, pressao, mtpHoje.Value, alerta);

                if (mtcbTemperaturas.Text == "C�")
                {
                    RelatorioC relatorioC = new RelatorioC();
                    List<RelatorioC> rel = relatorioC.listaRelatorioC();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "F�")
                {
                    RelatorioF relatorioC = new RelatorioF();
                    List<RelatorioF> rel = relatorioC.listaRelatorioF();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "K�")
                {
                    RelatorioK relatorioC = new RelatorioK();
                    List<RelatorioK> rel = relatorioC.listaRelatorioK();
                    DGVNormal.DataSource = rel;
                }
                if (mtcbTemperaturas.Text == "Todas")
                {
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFull();
                    DGVNormal.DataSource = li;
                }
                else if (mtcbTemperaturas.Text == "")
                {
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFull();
                    DGVNormal.DataSource = li;
                }
            }
        }

        private void cbModoPesquisa_CheckedChanged(object sender, EventArgs e)
        {
            if (cbModoPesquisa.Checked == true)
            {
                if (cbRisco.Checked)
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = false;
                    DGVRiscoPesquisa.Visible = true;
                }
                else
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = false; ;
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFullAlerta();
                    DGVRisco.DataSource = li;
                }
            }
            else if (cbModoPesquisa.Checked == false)
            {
                if (cbModoPesquisa.Checked)
                {
                    DGVNormal.Visible = false;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = true;
                    DGVRiscoPesquisa.Visible = false;
                }
                else
                {
                    DGVNormal.Visible = true;
                    DGVRisco.Visible = false;
                    DGVPesquisaNormal.Visible = false;
                    DGVRiscoPesquisa.Visible = false;
                    RelatorioFull rela = new RelatorioFull();
                    List<RelatorioFull> li = rela.listaRelatorioFullAlerta();
                    DGVRisco.DataSource = li;
                }
            }
        }
    }
}