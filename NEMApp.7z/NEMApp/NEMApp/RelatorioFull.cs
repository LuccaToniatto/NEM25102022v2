﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace NEMApp
{


   

    public class RelatorioFull
    {
        public int Id { get; set; }
        public int Celsius { get; set; }
        public int Kelvin { get; set; }
        public int Farenheit { get; set; }
        public int Pressao { get; set; }
        public DateTime Data { get; set; }
        public string alerta { get; set; }

        public List<RelatorioFull> listaRelatorioFull()
        {
            SqlConnection con = ClassConexao.ObterConexao();
            List<RelatorioFull> li = new List<RelatorioFull>();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Relatorio";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RelatorioFull re = new RelatorioFull();
                re.Id = (int)dr["Id"];
                re.Celsius = (int)dr["temperaturac"];
                re.Kelvin = (int)dr["temperaturak"];
                re.Farenheit = (int)dr["temperaturaf"];
                re.Pressao = (int)dr["pressao"];
                re.Data = Convert.ToDateTime(dr["data"]);
                re.alerta = dr["alerta"].ToString();
                li.Add(re);
            }
            return li;
        }

        public List<RelatorioFull> listaRelatorioFullAlerta()
        {
            SqlConnection con = ClassConexao.ObterConexao();
            List<RelatorioFull> li = new List<RelatorioFull>();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Relatorio WHERE alerta='!'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                RelatorioFull re = new RelatorioFull();
                re.Id = (int)dr["Id"];
                re.Celsius = (int)dr["temperaturac"];
                re.Kelvin = (int)dr["temperaturak"];
                re.Farenheit = (int)dr["temperaturaf"];
                re.Pressao = (int)dr["pressao"];
                re.Data = Convert.ToDateTime(dr["data"]);
                re.alerta = dr["alerta"].ToString();
                li.Add(re);
            }
            return li;
        }

        public void cadastrarrelatorio(int celcius, int kelvin, int farenheit, int pressao, DateTime data, string alerta)
        {
            SqlConnection con = ClassConexao.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Relatorio (temperaturac,temperaturak,temperaturaf,pressao,data,alerta) VALUES ('"+celcius+ "','"+kelvin+ "','"+farenheit+ "','"+pressao+ "',Convert(DateTime,'" + data + "',103),'" + alerta+"')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConexao.FecharConexao();
        }
    }
}
